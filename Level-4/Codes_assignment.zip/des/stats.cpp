#include <bits/stdc++.h>
using namespace std;

int main()
{
    ifstream analysis("analysis.txt");
    vector<long long> sum(8, 0);
    vector<int> max_val(8, 0);
    vector<int> index(8, 0);
    for (int i = 0; i < 8; i++)
    {
        int counter;
        analysis >> counter;
        for (int j = 0; j < 64; j++)
        {
            int num;
            analysis >> num;
            sum[i] += num;
            if (num > max_val[i])
            {
                max_val[i] = num;
                index[i] = j;
            }
        }
    }
    for (int i = 0; i < 8; i++)
    {
        cout << "avg : " << (sum[i] / 64) << " max : " << max_val[i] << " index : " << index[i] << endl;
    }
    return 0;
}