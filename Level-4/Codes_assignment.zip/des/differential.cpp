#include <bits/stdc++.h>
using namespace std;

int main1()
{

	ifstream output1;
	ofstream alphaxor, betaxor, reversefinalprem;
	vector<int> INV_RFP = {
		57, 49, 41, 33, 25, 17, 9, 1,
		59, 51, 43, 35, 27, 19, 11, 3,
		61, 53, 45, 37, 29, 21, 13, 5,
		63, 55, 47, 39, 31, 23, 15, 7,
		58, 50, 42, 34, 26, 18, 10, 2,
		60, 52, 44, 36, 28, 20, 12, 4,
		62, 54, 46, 38, 30, 22, 14, 6,
		64, 56, 48, 40, 32, 24, 16, 8
	};
	vector<int> E = {
		32, 1, 2, 3, 4, 5,
		4, 5, 6, 7, 8, 9,
		8, 9, 10, 11, 12, 13,
		12, 13, 14, 15, 16, 17,
		16, 17, 18, 19, 20, 21,
		20, 21, 22, 23, 24, 25,
		24, 25, 26, 27, 28, 29,
		28, 29, 30, 31, 32, 1
	};
	vector<int> INV_P = {
		9, 17, 23, 31,
		13, 28, 2, 18,
		24, 16, 30, 6,
		26, 20, 10, 1,
		8, 14, 25, 3,
		4, 29, 11, 19,
		32, 12, 22, 7,
		5, 27, 15, 21
	};

	output1.open("output1.txt");
	alphaxor.open("alphaxor.txt");
	betaxor.open("betaxor.txt");
	reversefinalprem.open("reversefinalprem.txt");
	string str1, str2;

	while (getline(output1, str1))
	{
		getline(output1, str2);
		vector<int> Str1(64), Str2(64), RFP_str1(64), RFP_str2(64), alphaxor_str(64);
		for (int i = 0; i < 64; i++)
		{
			Str1[i] = int(str1[i] - '0');
			Str2[i] = int(str2[i] - '0');
		}

		for (int i = 0; i < 64; i++)
		{
			RFP_str1[i] = Str1[INV_RFP[i] - 1];
			reversefinalprem << RFP_str1[i];
		}
		reversefinalprem << '\n';

		for (int i = 0; i < 64; i++)
		{
			RFP_str2[i] = Str2[INV_RFP[i] - 1];
			reversefinalprem << RFP_str2[i];
		}
		reversefinalprem << '\n';

		for (int i = 0; i < 64; i++)
		{
			alphaxor_str[i] = RFP_str1[i] ^ RFP_str2[i];
		}

		for (int i = 0; i < 48; i++)
		{
			int value = alphaxor_str[E[i] - 1];
			alphaxor << value;
		}
		alphaxor << '\n';

		for (int i = 0; i < 32; i++)
		{
			int value = alphaxor_str[INV_P[i] + 32 - 1];
			betaxor << value;
		}
		betaxor << '\n';
	}
	output1.close();
	alphaxor.close();
	betaxor.close();
	reversefinalprem.close();
	return 0;
}

int main2()
{

	int E[] = {
		32, 1, 2, 3, 4, 5,
		4, 5, 6, 7, 8, 9,
		8, 9, 10, 11, 12, 13,
		12, 13, 14, 15, 16, 17,
		16, 17, 18, 19, 20, 21,
		20, 21, 22, 23, 24, 25,
		24, 25, 26, 27, 28, 29,
		28, 29, 30, 31, 32, 1
	};

	vector<int> a(64), b(64), expanded1(48), expanded2(48);
	ifstream reversefinalprem;
	ofstream gammaout;
	gammaout.open("gammaxor.txt");
	reversefinalprem.open("reversefinalprem.txt");
	string s1, s2;
	while (getline(reversefinalprem, s1))
	{
		getline(reversefinalprem, s2);
		for (int i = 0; i < 64; i++)
		{
			a[i] = s1[i] - '0';
			b[i] = s2[i] - '0';
		}

		for (int i = 0; i < 48; i++)
		{
			expanded1[i] = a[E[i] - 1];
			expanded2[i] = b[E[i] - 1];
			gammaout << int(expanded1[i] ^ expanded2[i]);
		}
		gammaout << '\n';
	}
	gammaout.close();
	reversefinalprem.close();
	return 0;
}
int main()
{
	main1();
	main2();
	return 0;
}