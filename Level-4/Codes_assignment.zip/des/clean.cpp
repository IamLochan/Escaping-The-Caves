#include <bits/stdc++.h>
using namespace std;
int main1()
{
    ifstream fileoutput("human.txt");

    ofstream output_clean("output_clean.txt");
    string word;
    long long cnt = 0;
    while (fileoutput >> word)
    {
        if (word == "...")
        {
            fileoutput >> word;
            if (word.length() == 16)
            {
                output_clean << word << endl;
                cout << ++cnt << endl;
            }
        }
    }
    return 0;
}
string to_binary(char ch)
{
    map<char, string> mp;
    mp['f'] = "0000";
    mp['g'] = "0001";
    mp['h'] = "0010";
    mp['i'] = "0011";
    mp['j'] = "0100";
    mp['k'] = "0101";
    mp['l'] = "0110";
    mp['m'] = "0111";
    mp['n'] = "1000";
    mp['o'] = "1001";
    mp['p'] = "1010";
    mp['q'] = "1011";
    mp['r'] = "1100";
    mp['s'] = "1101";
    mp['t'] = "1110";
    mp['u'] = "1111";
    string ans = mp[ch];
    return ans;
}
int main2()
{
    ifstream output_clean("output_clean.txt");
    ofstream output1("output1.txt");
    string word;
    while (output_clean >> word)
    {
        string ans = "";
        for (char i : word)
        {
            string d = to_binary(i);
            ans += d;
        }
        output1 << ans << endl;
    }
    return 0;
}
int main()
{
    main1();
    main2();
    return 0;
}