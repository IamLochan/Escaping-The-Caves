#include <bits/stdc++.h>
using namespace std;

int main()
{
	vector<string> key = {"101101", "101101", "xxxxxx", "xxxxxx", "110001", "110001", "011111", "010010"};
	int perm[8][6] = {
		{24, 27, 21, 6, 11, 15},
		{13, 10, 25, 16, 3, 20},
		{5, 1, 22, 14, 8, 18},
		{26, 17, 9, 2, 23, 12},
		{51, 34, 41, 47, 29, 37},
		{40, 50, 33, 55, 43, 30},
		{54, 31, 49, 38, 44, 35},
		{56, 52, 32, 46, 39, 42}
	};
	// 45 45 51 13 49 49 31 18
	vector<char> expected(56, 'x');
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 6; j++)
		{
			expected[perm[i][j] - 1] = key[i][j];
		}
	}
	for (auto i : expected)
		cout << i;
	// xx0xx1xxx00x1x11xxx11xx11x0x0110011x11110001x00x1111x000
	return 0;
}