from string import ascii_lowercase
import sys
print("fsociety")
print("fsociety")
print("4")
print("read")
print("password")
print("c")
file = open("input_random.txt", 'r+')
for i in range(0, 2000000+1):
    print(file.readline())
    print("c")
print("back")
print("exit")
print("exit")
