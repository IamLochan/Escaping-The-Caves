
#include <bits/stdc++.h>
using namespace std;
int main1()
{
	long long random_number;
	ofstream random("random.txt");
	for (int j = 0; j < 1000000; j++)
	{
		string a = "";
		for (int i = 0; i < 64; i++)
		{
			random_number = rand() % 2;
			char ch = (char)'0' + random_number;
			a += ch;
		}
		random << a << '\n';
	}
	return 0;
}
int main2()
{
	FILE *fi, *fo;
	fi = fopen("random.txt", "r+");
	fo = fopen("input_random.txt", "w+");
	int i = 0;
	char input_string[64];
	int other_string[64];
	char chosen_first[17], chosen_second[17];
	vector<int> s = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

	while (i < 1000000)
	{
		fscanf(fi, "%s", input_string); // 64 bit input from random.txt
		for (int j = 0; j < 64; j++)
		{
			int t1 = int(input_string[j] - '0');
			other_string[j] = (t1 ^ s[j]); // input xor is S, hence the other string is input_string^S
		}
		int l;
		for (l = 0; l < 16; l++)
		{
			int h1, h2;
			h1 = (input_string[l * 4] - 48) * 8 + (input_string[l * 4 + 1] - 48) * 4 + (input_string[l * 4 + 2] - 48) * 2 + (input_string[l * 4 + 3] - 48); // converting to number in [0,16)
			h2 = other_string[l * 4] * 8 + other_string[l * 4 + 1] * 4 + other_string[l * 4 + 2] * 2 + other_string[l * 4 + 3];
			h1 += 102; // adding ascii of 'f' to input text
			h2 += 102;
			chosen_first[l] = h1;
			chosen_second[l] = h2;
		}
		chosen_first[l] = '\0';
		chosen_second[l] = '\0';
		i++;
		fprintf(fo, "%s\n", chosen_first);
		fprintf(fo, "%s\n", chosen_second);
	}
	return 0;
}

int main()
{
	main1();
	main2();
	return 0;
}