#include <bits/stdc++.h>
using namespace std;
#define ll long long
string to_binary(ll n)
{
    string ans = "";
    while (n > 0)
    {
        char d = '0' + n % 2;
        ans += d;
        n /= 2;
    }
    if (ans.length() >= 20)
        return ans;
    else
    {
        reverse(ans.begin(), ans.end());
        while (ans.length() < 20)
            ans += "0";
        reverse(ans.begin(), ans.end());
        return ans;
    }
}
string prefix = "XX1XX1XXX10X1X10XXX11XX10X0X0001110X00110001X01X0100X011";
int main()
{
    ll limit = 1;
    for (int i = 0; i < 20; i++)
        limit *= 2;
    ofstream key_out("key_out.txt");
    for (ll i = 0; i < limit; i++)
    {
        string ans = to_binary(i);
        vector<char> key(56);
        for (ll k = 0; k < 56; k++)
            key[k] = prefix[k];
        ll idx = 0;

        for (ll j = 0; j < 56; j++)
        {
            if (key[j] == 'X')
            {
                key[j] = ans[idx];
                idx++;
            }
        }
        for (auto e : key)
        {
            key_out << e;
        }
        key_out << '\n';
    }
    return 0;
}