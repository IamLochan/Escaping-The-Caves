#include <bits/stdc++.h>
using namespace std;
vector<string> ciphertext;
ofstream output_clean("output_clean.txt");
ifstream fileoutput("human.txt");
int main1() {
  string word;
  long long cnt = 0;
  while (fileoutput >> word) {
    if (word == "...") {
      fileoutput >> word;
      if (word.length() == 16) {
        cout << ++cnt << endl;
        ciphertext.push_back(word);
      }
    }
  }
  return 0;
}

int main() {
  main1();
  int k = 0;
  for (int i = 0; i < 8; i++) {
    for (int j = 0; j < 128; j++) {
      output_clean << ciphertext[k++] << " ";
    }
    output_clean << '\n';
  }
  return 0;
}