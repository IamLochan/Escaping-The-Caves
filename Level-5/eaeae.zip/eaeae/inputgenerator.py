import numpy as np
np.set_printoptions(threshold=np.inf)

mapping = {}
# Mapping contains the one to one map between numbers to alphabet in range f to u
for i in range(16):
    num = '{:0>4}'.format(format(i,"b")) # convert to binary number of length 4
    numi = int(num[3]) + 2 *int(num[2]) + int(num[1]) * 4 + int(num[0])*8 # convert to decimal
    mapping[num] = chr(ord('f')+numi)


file = open("inputs.txt","w+")
# Generation of input plaintext of type C_xPC_y such that x + y = 7
for i in range(8):
    for j in range(128):
        curr_ip_j = np.binary_repr(j, width=8) # 1 byte binary number 
        strr = 'ff'*i + mapping[curr_ip_j[:4]] + mapping[curr_ip_j[4:]] + 'ff'*(8-i-1)
        file.write(strr)
        file.write(" ")
    file.write("\n")
file.close()