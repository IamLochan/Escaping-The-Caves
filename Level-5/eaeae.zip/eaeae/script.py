print("fsociety")
print("fsociety")
print("5")
print("go")
print("wave")
print("dive")
print("go")
print("read")
print("password")
print("c")
file = open("inputs.txt","r+")
for line in file:
	for word in line.split():
		print(word)
		print("c")

print("back")
print("exit")
